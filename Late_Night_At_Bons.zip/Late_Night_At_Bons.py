import tkinter as tk
from tkinter import messagebox
import random
import time

class GameGUI:
    def __init__(self, master):
        self.master = master
        self.master.title("Bon's Burgers")
        self.master.geometry("800x600")

        self.bon_health = 50
        self.player_health = 30
        self.tools = {"screwdriver": 2, "wrench": 2, "hammer": 2}
        self.required_tool = None
        self.last_action_time = time.time()

        self.create_widgets()

    def create_widgets(self):
        self.health_label = tk.Label(self.master, text="Player Health: {}".format(self.player_health), font=("Courier New", 18))
        self.health_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")

        self.text_box = tk.Text(self.master, height=15, width=100, wrap=tk.WORD, font=("Courier New", 14))
        self.text_box.grid(row=1, column=0, padx=10, pady=10, sticky="w")

        self.actions_frame = tk.Frame(self.master)
        self.actions_frame.grid(row=2, column=0, padx=10, pady=10, sticky="w")

        self.inspect_button = tk.Button(self.actions_frame, text="Inspect", command=self.inspect_bon, font=("Courier New", 14))
        self.inspect_button.pack(side=tk.LEFT, padx=5)

        self.repair_button = tk.Button(self.actions_frame, text="Repair", command=self.repair_bon, font=("Courier New", 14))
        self.repair_button.pack(side=tk.LEFT, padx=5)

        self.run_button = tk.Button(self.actions_frame, text="Run", command=self.run_away, font=("Courier New", 14))
        self.run_button.pack(side=tk.LEFT, padx=5)

        self.update_health_label()

        self.start_game()

    def start_game(self):
        self.print_to_text_box("Welcome to Bon's Burgers. You are a technician trying to fix Bon.")
        self.print_to_text_box("Be careful, as Bon might attack you!")

    def print_to_text_box(self, text, delay=0.05):
        for char in text:
            self.text_box.insert(tk.END, char)
            self.text_box.see(tk.END)  # Auto-scroll to the bottom
            self.master.update()
            time.sleep(delay)
        self.text_box.insert(tk.END, "\n")
        self.text_box.see(tk.END)  # Auto-scroll to the bottom

    def update_health_label(self):
        self.health_label.config(text="Player Health: {}".format(self.player_health))

    def inspect_bon(self):
        required_tool = self.get_random_tool()
        self.print_to_text_box("You inspect Bon for any issues.")
        time.sleep(2)
        self.print_to_text_box(f"You find an issue. Use {required_tool} to fix it.")
        self.required_tool = required_tool

    def repair_bon(self):
        self.show_tool_selection()

    def run_away(self):
        self.print_to_text_box("You try to run away from Bon.")
        time.sleep(2)
        self.print_to_text_box("Bon catches you, and you lose some health.")
        self.bon_turn()

    def surprise_attack(self):
        self.print_to_text_box("Surprise attack! Bon catches you off guard.")
        damage = random.randint(30, 45)
        self.player_health -= damage
        self.print_to_text_box(f"You lose {damage} health.")
        self.update_health_label()
        if self.player_health <= 0:
            self.game_over()

    def bon_turn(self):
        damage = random.randint(25, 40)
        self.player_health -= damage
        self.print_to_text_box(f"Bon attacks! You lose {damage} health.")
        self.update_health_label()
        if self.player_health <= 0:
            self.game_over()

    def game_over(self):
        messagebox.showinfo("Game Over", "Bon defeated you.")
        self.master.destroy()

    def show_tool_selection(self):
        tool_selection_window = tk.Toplevel(self.master)
        tool_selection_window.title("Select a Tool")
        tool_selection_window.geometry("400x200")

        tool_label = tk.Label(tool_selection_window, text="Select a tool to repair Bon:", font=("Courier New", 16))
        tool_label.pack(pady=10)

        for tool in self.tools.keys():
            button = tk.Button(tool_selection_window, text=tool.capitalize(), command=lambda t=tool: self.use_tool(t), font=("Courier New", 14))
            button.pack(pady=5)

    def use_tool(self, selected_tool):
        if self.tools[selected_tool] > 0:
            self.tools[selected_tool] -= 1
            self.update_health_label()
            self.print_to_text_box(f"You use {selected_tool} to repair Bon.")
            self.print_to_text_box("You successfully repair Bon!")
            self.required_tool = None
            if random.random() < 0.2:
                self.surprise_attack()
            else:
                self.bon_turn()
        else:
            self.print_to_text_box(f"You don't have any {selected_tool} left.")

    def get_random_tool(self):
        return random.choice(list(self.tools.keys()))


def main():
    root = tk.Tk()
    game_gui = GameGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
